import logo from './logo.svg';
import Home from "./pages/Home";
import About from "./pages/About";
import Contactus from "./pages/Contactus";
import Consulting from "./pages/Consulting";
import Mobile from "./pages/Mobile";
import Development from "./pages/Development";
import Infrastructure from "./pages/Infrastructure";
import Products from './pages/Products';

import Header from "./components/Header";
import Footer from "./components/Footer";

import {  BrowserRouter, Routes, Route, useSearchParams } from 'react-router-dom';
import './App.css';

function App() {
  // let [searchParams, setSearchParams] = useSearchParams();

  function handleSubmit(event) {
    event.preventDefault();
    // The serialize function here would be responsible for
    // creating an object of { key: value } pairs from the
    // fields in the form that make up the query.
    // let params = serializeFormQuery(event.target);
    // searchParams.get("__firebase_request_key")
    // setSearchParams({});
  }


  return (
    <BrowserRouter>
    <Header/>
    <form onSubmit={handleSubmit}>{/* ... */}</form>
    <Routes>
    <Route exact path="/" element={<Home/>}/>
    <Route path="/about" element={<About/>}/>
    <Route path="/contactus" element={<Contactus/>}/>
    <Route path="/consulting" element={<Consulting/>}/>
    <Route path="/mobile" element={<Mobile/>}/>
    <Route path="/development" element={<Development/>}/>
    <Route path="/infra" element={<Infrastructure/>}/>
    <Route path="/products" element={<Products/>}/>
    </Routes>
    <Footer/>
    </BrowserRouter>

  );
}

export default App;
