import React from "react";
class Home extends React.Component {
  render() {
    return (
      <body ng-app="docsTemplateUrlDirective">
        <div className="page">
          <div className="mainBody">
            <div className="bannerBlock">
              <div id="banner-slide" style={{ margin: "auto" }}>
                <ul className="bjqs">
                  <li>
                    <img
                      className="bannerImg"
                      alt=""
                      src={require("../images/proBg.png")}
                      width="10%"
                    />
                  </li>
                </ul>
              </div>
            </div>
            <div className="aboutBlock">
              <div className="abtContent">
                <div className="content padLarge" align="center">
                  <span
                    className="homeTitle"
                    style={{ color: "rgb(23, 134, 161)" }}
                  >
                    Digital Transformation and Core Technologies
                  </span>
                  <div className="cta">
                    <div>
                      <img src={require("../images/cta-12.png")} alt="" />
                      <br />
                      Change is not easy. Encourage teams by training with core
                      skills. Be the seed of <b>Lean Agile DevOps</b> culture in
                      your organization.{" "}
                    </div>
                  </div>
                  <div className="cta">
                    <div>
                      <img src={require("../images/cta-11.png")} alt="" />
                      <br />
                      Avoid configuration drift between development and
                      production environments using{" "}
                      <a href="https://www.terraform.io">
                        Infrastructure as code
                      </a>
                      . i.e., Better and fast cycles{" "}
                      <b>Build>>Measure>>Learn</b>{" "}
                    </div>
                  </div>
                  <div className="cta">
                    <div>
                      <img src={require("../images/cta-13.png")} alt="" />
                      <br />
                      Application packed with new features in a{" "}
                      <a href="https://docker.io">Docker</a> container with its
                      environment. Test, ship and deploy an immutable docker
                      image. Scale up in seconds for better user experience!{" "}
                    </div>
                  </div>
                  <div className="cta">
                    <div>
                      <img src={require("../images/cta-14.png")} alt="" />
                      <br />
                      Develop loosely coupled architecture to release each
                      feature or set of features much faster. Deploy and
                      orchestrate microservices using{" "}
                      <a href="https://kubernetes.io">kubernetes</a>{" "}
                    </div>
                  </div>
                  <br />
                  <br />
                  <br />
                </div>
              </div>
            </div>
            <div className="productsBlock">
              <div className="proContent">
                <div className="contentHome padLarge" align="center">
                  <div className="contentLeft">
                    <span className="homeTitle" style={{ color: `obj.#fff` }}>
                      Our Clients
                    </span>
                    <div className="customers">
                      <div className="custLogo">
                        <div className="cLogo">
                          <img src={require("../images/hpe-logo.png")} alt="" />
                        </div>
                      </div>
                      <div className="custLogo">
                        <div className="cLogo">
                          <img
                            src={require("../images/stem-logo.png")}
                            alt=""
                          />
                        </div>
                      </div>
                      <div className="custLogo">
                        <div className="cLogo">
                          <img
                            src={require("../images/volvo-logo.png")}
                            alt=""
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div style={{ clear: "both", height: "50px" }}></div>
            </div>
          </div>
        </div>
      </body>
    );
  }
}
export default Home;
