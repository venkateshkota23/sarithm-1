import React from "react";
class Contactus extends React.Component {
  render() {
    return (
      <div>
        <div className="mainBody">
          <div className="bannerBlock1">
            <div
              style={{
                position: "absolute",
                right: "0px",
                width: "250px",
                height: "155px",
                backgroundimage: "url(images/globe.png)",
                backgroundposition: "-0px -40px",
              }}
            ></div>
            <div className="bannerContent">
              <div className="content">
                <span className="pageTitle">CONTACT US</span>
                <br />
                <span className="subTitle">
                  Invest with us, we got projects waiting for you. <br />
                  Contact us for details....
                </span>
              </div>
            </div>
          </div>

          <div classNameName="content padSmall">
            <div className="subTitle1">Address</div>
            <p>300 parsippany road, NJ</p>
            <div className="subTitle1">E Mail</div>
            <p>info.com</p>
            <div className="subTitle1">Contact Number</div>
            <p>+1206-440-4333</p>
            <br />
            <br />
            <br />
          </div>
        </div>
        <div style={{ clear: "both" }}></div>
      </div>
    );
  }
}
export default Contactus;
