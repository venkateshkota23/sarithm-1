import React from "react";
class About extends React.Component {
	render() {
		return (
			<main>
            <div className="mainBody">
			<div className="bannerBlock1">
				<div style={{position:'absolute', right:'0px', width:'250px', height:'155px', backgroundimage:'url(images/globe.png)', backgroundposition:'-0px -40px'}}></div>
      			<div className="bannerContent">
      			<div className="content"><span className="pageTitle">ABOUT US</span><br/><span className="subTitle">Our passion for software development truly goes hand in hand <br/>with mobile technology...</span></div>
      			</div>
      		</div>
			<div className="content padSmall">
				<p>We are Application Developers with prior experience in System Programming, System Administration, Application Architecture and IT Architecture.  In other words, we are end-to-end Application Development Team. </p>
	<p>We develop IT environment friendly applications, which present a deep understanding of Operating System management. We strive to conceptualize smart algorithms, which have the ability to monitor and build on one another. Our application’s framework comes with built-in high availability and are self-healing. It is imperative that our application developers have a tremendous understanding of Operating Systems Management. It is one thing to be able to code, while it is another altogether to understand how the code is going to be segmented and executed by the Operating System. </p>
	<p>We believe that communication is the key to success in any business relationship. A deep understanding of the project, well defined requirements, and a solid tracking system lead to not only a successful result but also time saved. From the beginning we will ask the needed questions, and begin work immediately to increase efficiencies and to provide a quick turn around. The process of software development is difficult to track using traditional methods. Instead, we use modular programming, which allows every module to be sectored, reallocated, and tested independently from the others.</p>
				<br/><br/><br/>
			</div>
		</div>
		<div style={{clear:'both'}}></div>
            </main>
        )
        }
}
export default About;
