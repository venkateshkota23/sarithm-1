import React from "react";
import { NavLink } from "react-router-dom";

class Header extends React.Component {
  render() {
    return (
      <header>
        <div class="header">
          <div class="headerContent">
            <div class="logo">
              <a>
                <NavLink to="/" activeClassName="active">
                  <img src="logo" alt="" />
                </NavLink>
              </a>
            </div>
            <div class="showmmenu">
              <span
                style={{
                  display: "block",
                  border: "#333333 5px solid",
                  height: "5px",
                  width: "20px",
                }}
              ></span>
              <span
                style={{
                  display: "block",
                  border: "#333333 5px solid",
                  height: "5px",
                  width: "20px",
                }}
              ></span>
              <span
                style={{
                  display: "block",
                  border: "#333333 5px solid",
                  width: "20px",
                }}
              ></span>
            </div>
            <div class="mobileMenu">
              <div style={{ backgroundcolor: "#333333", color: "white" }}>
                <ul>
                  <li class="menuItem">
                    <a href="products.html">PRODUCTS</a>
                  </li>
                  <li class="menuItem about">
                    <a href="/service">SERVICES</a>
                    <div class="mabtMenu">
                      <ul
                        class="msubMenu"
                        style={{
                          position: "relative",
                          top: "10px",
                          left: "-10px",
                        }}
                      >
                        <a href="mobile.html">
                          <li class="subMenuItem">MOBILE</li>
                        </a>
                        <a href="development.html">
                          <li class="subMenuItem">
                            SOFTWARE
                            <br />
                            DEVELOPMENT
                          </li>
                        </a>
                        <a href="consulting.html">
                          <li class="subMenuItem">IT CONSULTING</li>
                        </a>
                        <a href="infra.html">
                          <li class="subMenuItem">
                            INFRASTRUCTURE
                            <br />
                            MAINTENANCE
                          </li>
                        </a>
                      </ul>
                    </div>
                  </li>
                  <li class="menuItem projects">
                    <a href="learning.html" style={{ display: "block" }}>
                      LEARN
                    </a>
                  </li>
                  <li class="menuItem">
                    <a href="contactus.html">COMPANY</a>
                    <div class="mcompMenu" style={{ zindex: "10" }}>
                      <ul
                        class="msubMenu"
                        style={{
                          position: "relative",
                          top: "18px",
                          left: "-20px",
                        }}
                      >
                        <a href="aboutus.html">
                          <li class="subMenuItem">ABOUT US</li>
                        </a>
                        <a href="contactus.html">
                          <li class="subMenuItem">CONTACT US</li>
                        </a>
                      </ul>
                    </div>
                    <div style={{ clear: "both" }}></div>
                  </li>
                </ul>
                <p>&nbsp;</p>
              </div>
            </div>

            <div class="menu">
              <ul>
                <li class="menuItem">
                  <a href="products.html">PRODUCTS</a>
                </li>
                <li class="menuItem">
                  <a href="services.html">SERVICES</a>
                  <div
                    class="abtMenu"
                    style={{ position: "absolute", zindex: "10" }}
                  >
                    <ul
                      class="subMenu"
                      style={{
                        position: "relative",
                        top: "18px",
                        left: "-20px",
                      }}
                    >
                      <a href="mobile.html">
                        <li class="subMenuItem">MOBILE</li>
                      </a>
                      <a href="development.html">
                        <li class="subMenuItem">
                          SOFTWARE
                          <br />
                          DEVELOPMENT
                        </li>
                      </a>
                      <a href="consulting.html">
                        <li class="subMenuItem">IT CONSULTING</li>
                      </a>
                      <a href="infra.html">
                        <li class="subMenuItem">
                          INFRASTRUCTURE
                          <br />
                          MAINTENANCE
                        </li>
                      </a>
                    </ul>
                  </div>
                </li>
                <li class="menuItem">
                  <a href="learning.html" style={{ display: "block" }}>
                    LEARN
                  </a>
                </li>
                <li class="menuItem comp">
                  <a>
                    {" "}
                    <NavLink to="/about" activeClassName="active">
                      COMPANY
                    </NavLink>
                  </a>
                  <div
                    class="compMenu"
                    style={{ position: "absolute", zindex: "10" }}
                  >
                    <ul
                      class="subMenu"
                      style={{
                        position: "relative",
                        top: "18px",
                        left: "-20px",
                      }}
                    >
                      <a>
                        {" "}
                        <NavLink to="/about" activeClassName="active">
                          About
                        </NavLink>{" "}
                        <li class="subMenuItem">ABOUT US</li>
                      </a>
                      <a href="contactus.html">
                        <li class="subMenuItem">CONTACT US</li>
                      </a>
                    </ul>
                  </div>
                </li>
              </ul>
            </div>
          </div>
          <div style={{ clear: "both" }}></div>
        </div>
      </header>
    );
  }
}

export default Header;
