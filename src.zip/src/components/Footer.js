import React from "react";
import { NavLink } from "react-router-dom";

class Footer extends React.Component {
  render() {
    return (
      <footer>
        <div class="mobileFooter">
          Copyright © 2017 2018 All rights reserved.
        </div>
        <div class="footer">
          <div class="footerContent">
            <div class="footerBlock">
              <span class="footerTitle">COMPANY</span>
              <a>
                <NavLink to="/about" activeClassName="active">
                  ABOUT US
                </NavLink>
              </a>
              <br />
              <a>
                <NavLink to="/contactus" activeClassName="active">
                  CONTACT US
                </NavLink>
              </a>
              <br />
              <a>
                <NavLink to="/learn" activeClassName="active">
                  LEARN
                </NavLink>
              </a>
              <br />
            </div>
            <div class="footerBlock1">
              <span class="footerTitle">PRODUCTS</span>
              <a>
                <NavLink to="/products" activeClassName="active">
                  XSTRAW
                </NavLink>
              </a>
              <br />
              <a>
                <NavLink to="/products" activeClassName="active">
                  MINICASH
                </NavLink>
              </a>
              <br />
            </div>
            <div class="footerBlock1">
              <span class="footerTitle">SERVICES</span>
              <a>
                <NavLink to="/mobile" activeClassName="active">
                  MOBILE
                </NavLink>
              </a>
              <br />
              <a>
                <NavLink to="/development" activeClassName="active">
                  SOFTWARE DEVELOPMENT
                </NavLink>
              </a>{" "}
              <br />
              <a>
                <NavLink to="/consulting" activeClassName="active">
                  IT CONSULTING
                </NavLink>
              </a>
              <br />
              <a>
                <NavLink to="/infra" activeClassName="active">
                  INFRASTRUCTURE MAINTENANCE
                </NavLink>
              </a>
            </div>
            <div class="footerBlock1">
              <span class="footerTitle">FOLLOW US</span>
              <div>
                <a href="https://www.facebook.com" target="_blank">
                  <img
                    src={require("../images/social01.png")}
                    align="left"
                    style={{ width: "30px" }}
                  />
                </a>
                <a href="https://twitter.com" target="_blank">
                  <img
                    src={require("../images/social02.png")}
                    align="left"
                    style={{ marginleft: "10px", width: "30px" }}
                  />
                </a>
                <a href="https://www.linkedin.com" target="_blank">
                  <img
                    src={require("../images/social03.png")}
                    align="left"
                    style={{ marginleft: "10px", width: "30px" }}
                  />
                </a>
                <a href="https://github.com" target="_blank">
                  <img
                    src={require("../images/social04.png")}
                    align="left"
                    style={{ marginleft: "10px", width: "30px" }}
                  />
                </a>
                <a href="mailto:info@gmail.com" target="_blank">
                  <img
                    src={require("../images/emailIco.png")}
                    align="left"
                    style={{ marginleft: "10px" }}
                  />
                </a>
                <br />
                <br />
              </div>
            </div>
          </div>
        </div>
      </footer>
    );
  }
}

export default Footer;
